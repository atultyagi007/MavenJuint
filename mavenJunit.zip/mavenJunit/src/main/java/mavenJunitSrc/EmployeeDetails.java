package mavenJunitSrc;

public class EmployeeDetails {
	
		private String name;
		private double monthlySalary;
		private int age;
		
		public String getName() {
			return name;
		}
		public double getMonthlySalary() {
			return monthlySalary;
		}
		public int getAge() {
			return age;
		}
		public void setName(String name) {
			this.name = name;
		}
		public void setMonthlySalary(double monthlySalary) {
			this.monthlySalary = monthlySalary;
		}
		public void setAge(int age) {
			this.age = age;
		}
		@Override
		public String toString() {
			return "EmployeeDetails [name=" + name + ", monthlySalary=" + monthlySalary + ", age=" + age + "]";
		}
		

}
