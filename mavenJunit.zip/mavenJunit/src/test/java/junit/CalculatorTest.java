package junit;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Collection;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import mavenJunitSrc.Calculator;
import mavenJunitSrc.ICalculator;

@RunWith(value= Parameterized.class)
public class CalculatorTest {
	
	@Parameter(value=0)
	public int a;
	@Parameter(value=1)
	public int b;
	@Parameter(value=2)
	public int z;
	
	private static ICalculator calculator;
	Logger logger= Logger.getLogger("CalculatorTest");
	
	
	@Parameters(name = "{index}: test({0}+{1}) = {2}")    //name attribute is optional
	public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
                {1, 1, 2},
                {2, 2, 4},
                {8, 2, 10},
                {4, 5, 9},
                {5, 5, 10}
        });
    }

	@BeforeClass
	public static void initCalculator() {
		calculator = new Calculator();
	}

	@Before
	public void beforeEachTest() {
		//System.out.println("This is executed before each Test");
		logger.info("This is executed before each Test");
	}

	@After
	public void afterEachTest() {
		//System.out.println("This is exceuted after each Test");
		logger.debug("This is exceuted after each Test");
	}

	@Test
	public void testSum() {
		int result = calculator.sum(a, b);

		assertEquals(z, result);
	}

	@Test
	public void testDivison() {
		try {
			int result = calculator.divison(a, b);

			assertEquals(a/b, result);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

	@Test(expected = Exception.class)
	public void testDivisionException() throws Exception {
		calculator.divison(10, 0);
	}

	@Ignore
	@Test
	public void testEqual() {
		boolean result = calculator.equalIntegers(20, 20);

		assertFalse(result);
	}

	@Ignore
	@Test
	public void testSubstraction() {
		int result = 10 - 3;

		assertTrue(result == 9);
	}
}
