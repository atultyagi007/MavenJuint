package junit;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import mavenJunitSrc.EmpBusinessLogic;
import mavenJunitSrc.EmployeeDetails;

public class EmpBussinessLogicTest {
	
	EmployeeDetails emp1= new EmployeeDetails();
	EmpBusinessLogic logic = new EmpBusinessLogic();
	
	 @Before
	   public void before() {
	      System.out.println("in before");
	   }
		
	   //execute after test
	   @After
	   public void after() {
	      System.out.println("in after");
	   }
		

	@Test
	public void testcalculateYearlySalary() {
		System.out.println("testcalculateYearlySalary");
		emp1.setAge(30);
		emp1.setMonthlySalary(10000);
		emp1.setName("atul");
		
		assertEquals(120000,logic.calculateYearlySalary(emp1),0.0);
		
	}
	
	@Test
	public void testCalculateAppraisal(){
		System.out.println("testCalculateAppraisal");
		emp1.setAge(30);
		emp1.setMonthlySalary(10000);
		emp1.setName("atul");
		
		assertEquals(1000,logic.calculateAppraisal(emp1),0.0);
		
		
	}

}
